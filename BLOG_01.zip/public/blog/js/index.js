/**
 * Created by 123 on 2017/3/5.
 */

$(function(){
    var num=0;
  var t=$('.blogList img').attr('title');
    console.log(t);

})
















