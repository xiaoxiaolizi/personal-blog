<?php
/**
 * 配置文件
 */
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'blog2',
    'DB_USER' => 'root',
    'DB_PWD' => '',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'blog_',
    //密钥
    "AUTHCODE" => '5C1nuDtwus1gDQjuml',
    //cookies
    "COOKIE_PREFIX" => '3IBnPb_',
);
