<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no,maximum-scale=1">
    <meta name="keywords" content="个人博客,向丽个人博客,个人网站,web前端工程师,向丽">
    <meta name="description" content="向丽个人博客,是一个分享学习web前端的成长历程和心得体会，关注向丽博客，一起参与技术探讨和学习，了解最新趋势和下载免费web学习资源等的个人原创网站">
    <title>关于我--一个半路出家行走在web前端道路的女程序猿的学习成长之路</title>
    <link rel="stylesheet" href="/BLOG_01/public/blog/css/reset.css"/>
    <link rel="stylesheet" href="/BLOG_01/public/blog/css/common.css"/>
    <link rel="stylesheet" href="/BLOG_01/public/blog/css/about.css"/>
</head>
<body style="background:#fff;">
<div class="header">
    <header>
        
    <img src="/BLOG_01/public/blog/img/logo3.png" alt="" class="lf"/>
    <div class="person_title lf">
       <ul>
           <li class="active"><a href="index.html">首页</a></li>
<li><a href="study.html?term_id=4">学无止境</a></li>
<li><a href="slowLife.html">诗和远方</a></li>
<li><a href="gossip.html">随便说说</a></li>
<li><a href="aboutMe.html">关于我</a></li>
<li><a href="messageBoard.html">留言板</a></li>
       </ul>
    </div>

    </header>
</div>

    <nav class="detail-nav">
        <ul class="nav-list">
            <li class="active"><a href="index.html">首页</a></li>
            <li><a href="#">关于我</a></li>
        </ul>
        <ul class="addr-list">
          <img src="/BLOG_01/public/blog/img/5849.png" alt=""/>您当前位置：<span>关于我</span>
        </ul>
    </nav>

<section>
    <div class="content-left rf">
            <div class="contents">
                <?php if(is_array($aboutMe)): foreach($aboutMe as $key=>$vo): ?><div class="aboutMe">
                   <?php echo ($vo["post_content"]); ?>
                </div><?php endforeach; endif; ?>
            </div>



    </div>
    <aside class="content-right lf">
        <?php if(is_array($hostuser)): foreach($hostuser as $key=>$vo): ?><div class="touxiang">
              <img src="/BLOG_01/public/blog/img/<?php echo ($vo["img2"]); ?>" alt=""/>
              <p>网名：<span><?php echo ($vo["webname"]); ?></span></p>
              <p>姓名：<span><?php echo ($vo["uname"]); ?></span></p>
              <p>生日：<span><?php echo ($vo["birthday"]); ?></span></p>
              <p>家乡：<span><?php echo ($vo["hometown"]); ?></span></p>
              <p>工作地点：<span><?php echo ($vo["jobaddr"]); ?></span></p>
              <p>职业：<span><?php echo ($vo["job"]); ?></span></p>
              <p>邮箱：<span><?php echo ($vo["email"]); ?></span></p>
          </div><?php endforeach; endif; ?>
    </aside>
</section>
<div class="footer">
    <footer>
        
    <p>DESIGN by xiangli<a href="http://www.miitbeian.gov.cn/"> 粤ICP备17020426号</a></p>

    </footer>
</div>

<script src="/BLOG_01/public/blog/js/jquery-1.11.3.js"></script>
<script src="/BLOG_01/public/blog/js/common.js"></script>
<script src="/BLOG_01/public/blog/js/about.js"></script>
</body>
</html>