<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no,maximum-scale=1">
    <meta name="keywords" content="个人博客,向丽个人博客,个人网站,web前端工程师,向丽">
    <meta name="description" content="向丽个人博客,是一个分享学习web前端的成长历程和心得体会，关注向丽博客，一起参与技术探讨和学习，了解最新趋势和下载免费web学习资源等的个人原创网站">
    <title>向丽个人博客--一个半路出家行走在web前端道路的女程序猿的学习成长之路</title>
    <link rel="stylesheet" href="/BLOG_01/public/blog/css/reset.css"/>
    <link rel="stylesheet" href="/BLOG_01/public/blog/css/common.css"/>
    <link rel="stylesheet" href="/BLOG_01/public/blog/css/index.css"/>
</head>
<body>
   <div class="header">
       <header>
           <img src="/BLOG_01/public/blog/img/logo3.png" alt="" class="lf"/>
           <div class="person_title1 lf">
               <p>向丽的个人网站--个人博客</p>
               <p>记录一个半路出家行走在web前端道路的女程序猿的学习成长之路</p>
           </div>
       </header>
   </div>
   <nav>
       <ul>
           <li class="active"><a href="index.html">首页</a></li>
<li><a href="study.html?term_id=4">学无止境</a></li>
<li><a href="slowLife.html">诗和远方</a></li>
<li><a href="gossip.html">随便说说</a></li>
<li><a href="aboutMe.html">关于我</a></li>
<li><a href="messageBoard.html">留言板</a></li>
       </ul>
   </nav>
   <section>

       <div class="content-left lf">
           <h1 class="new_blog">文章推荐</h1>
           <?php if(is_array($recommended)): foreach($recommended as $key=>$vo): ?><div class="blogList">
                       <h2 class="article-title"><span>→</span><a href="articelDetail.html?term_id=4&id=<?php echo ($vo["id"]); ?>&hits=<?php echo ($vo["post_hits"]); ?>"><?php echo ($vo["post_title"]); ?> </a></h2>
                       <?php $smeta=json_decode($vo['smeta'],true); ?>
                       <div class="lf img">
                           <img src="<?php echo sp_get_asset_upload_path($smeta['thumb']);?>" />
                       </div>
                       <div class="rf article-content">
                          <p> <?php if($vo["post_excerpt"] !='' ): echo ($vo["post_excerpt"]); ?>
                              <?php else: ?>  <?php echo ($vo["post_content"]); endif; ?></p>
                           <p class="readmore rf"><a href="articelDetail.html?term_id=4&id=<?php echo ($vo["id"]); ?>&hits=<?php echo ($vo["post_hits"]); ?>">阅读全文>></a></p>
                       </div>
                       <p class="dateview lf">
                           <span><img src="/BLOG_01/public/blog/img/timebg.png" alt=""/> <?php echo ($vo["post_modified"]); ?></span>
                           <span>阅读(<?php echo ($vo["post_hits"]); ?>)</span>
                           <span>评论数(<span id = "sourceId::<?php echo ($vo["id"]); ?>" class = "cy_cmt_count" ></span>)</span>
                         <!---  <span>评论数(<span id = "url::http://www.lizi5825.com/articelDetail.html?term_id=4&id=<?php echo ($vo["id"]); ?>" class = "cy_cmt_count" ></span>)</span>-->
                           <script id="cy_cmt_num" src="http://changyan.sohu.com/upload/plugins/plugins.list.count.js?clientId=cysUtSuOV">
                           </script>

                       </p>
                   </div><?php endforeach; endif; ?>

       </div>

        <aside class="content-right rf">
            <audio controls autoplay loop>
                <?php if(is_array($audios)): foreach($audios as $key=>$vo): ?><source src="/BLOG_01/public/blog/audio/<?php echo ($vo["url"]); ?>"/><?php endforeach; endif; ?>
            </audio>
             <div class="motto">
                 <?php if(is_array($mottos)): foreach($mottos as $key=>$vo): ?><p><?php echo ($vo["motto"]); ?></p><?php endforeach; endif; ?>
             </div>

             <div class="about">
                 <?php if(is_array($hostuser)): foreach($hostuser as $key=>$vo): ?><img src="/BLOG_01/public/blog/img/<?php echo ($vo["img"]); ?>" alt="" class="lf"/>
                    <div class="lf">
                        <p>网名：<?php echo ($vo["webname"]); ?></p>
                        <p>生日：<?php echo ($vo["birthday"]); ?></p>
                        <p>籍贯：<?php echo ($vo["hometown"]); ?></p>
                        <p>职业：<?php echo ($vo["job"]); ?></p>
                        <p>工作城市：<?php echo ($vo["jobaddr"]); ?></p>
                    </div><?php endforeach; endif; ?>
             </div>

            <div class="recommend">
                 <h2 class="article-recommend">最新日志</h2>
                <ul>
                    <?php if(is_array($ArticleList['posts'])): foreach($ArticleList['posts'] as $key=>$vo): ?><li><img src="/BLOG_01/public/blog/img/list.gif" alt=""/><a href="articelDetail.html?term_id=4&id=<?php echo ($vo["id"]); ?>&hits=<?php echo ($vo["post_hits"]); ?>"><?php echo ($vo["post_title"]); ?></a></li><?php endforeach; endif; ?>
                </ul>
            </div>
            <div class="bdsharebuttonbox bdshare-button-style1-32" data-bd-bind="1488693175859">
                <a href="http://www.lizi5825.com/#" class="bds_more" data-cmd="more"></a>
                <a href="http://www.lizi5825.com/#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a>
                <a href="http://www.lizi5825.com/#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
                <a href="http://www.lizi5825.com/#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a>
                <a href="http://www.lizi5825.com/#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a>
                <a href="http://www.lizi5825.com/#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a>
            </div>
            <div class="attention">扫描二维码关注<span>向丽博客</span>官方微信账号</div>
            <div class="qr">
                <a href="http://www.lzi5825.com/" class="weChat">
                    <img src="/BLOG_01/public/blog/img/qrcode.jpg" alt=""/>
                </a>
            </div>
        </aside>

       <ul class="links">
         <?php if(is_array($links)): foreach($links as $key=>$vo): ?><li><a href="<?php echo ($vo["link_url"]); ?>"><?php echo ($vo["link_name"]); ?></a></li><?php endforeach; endif; ?>
       </ul>
   </section>

   <div class="footer">
       <footer>
           
    <p>DESIGN by xiangli<a href="http://www.miitbeian.gov.cn/"> 粤ICP备17020426号</a></p>

       </footer>
   </div>

   <script src="/BLOG_01/public/blog/js/jquery-1.11.3.js"></script>
   <script src="/BLOG_01/public/blog/js/common.js"></script>
   <script src="/BLOG_01/public/blog/js/index.js"></script>

</body>
</html>