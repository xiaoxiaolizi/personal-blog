<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no,maximum-scale=1">
    <meta name="keywords" content="个人博客,向丽个人博客,个人网站,web前端工程师,向丽">
    <meta name="description" content="向丽个人博客,是一个分享学习web前端的成长历程和心得体会，关注向丽博客，一起参与技术探讨和学习，了解最新趋势和下载免费web学习资源等的个人原创网站">
    <title>关于我--一个半路出家行走在web前端道路的女程序猿的学习成长之路</title>
    <link rel="stylesheet" href="/BLOG_01/public/blog-m/css/reset.css"/>
    <link rel="stylesheet" href="/BLOG_01/public/blog-m/css/common.css"/>
    <link rel="stylesheet" href="/BLOG_01/public/blog-m/css/about.css"/>
</head>
<body style="background:#fff;">
<div class="header">
    <header>
        
    <img src="/BLOG_01/public/blog-m/img/logo3.png" alt="" class="lf"/>
    <img src="/BLOG_01/public/blog-m/img/icon-s_r3_c14.png" alt="" class="rf m"/>

    </header>
</div>

    <nav class="detail-nav">
        <ul class="mainM">
            <li class="active"><a href="index.html">首页</a></li>
<li><a href="study.html?term_id=4">学无止境</a></li>
<li><a href="slowLife.html">诗和远方</a></li>
<li><a href="gossip.html">随便说说</a></li>
<li><a href="aboutMe.html">关于我</a></li>
<li><a href="messageBoard.html">留言板</a></li>
        </ul>
        <ul class="nav-list">
            <li class="active"><a href="index.html">首页</a></li>
            <li><a href="#">关于我</a></li>
        </ul>
    </nav>

<section>
    <div class="content-left rf">
            <div class="contents">
                <?php if(is_array($aboutMe)): foreach($aboutMe as $key=>$vo): ?><div class="aboutMe">
                   <?php echo ($vo["post_content"]); ?>
                </div><?php endforeach; endif; ?>
            </div>



    </div>
</section>
<div class="footer">
    <footer>
        
    <p>DESIGN by xiangli<a href="http://www.miitbeian.gov.cn/"> 粤ICP备17020426号</a></p>

    </footer>
</div>

<script src="/BLOG_01/public/blog-m/js/jquery-1.11.3.js"></script>
<script src="/BLOG_01/public/blog-m/js/common.js"></script>
<script src="/BLOG_01/public/blog-m/js/about.js"></script>
</body>
</html>