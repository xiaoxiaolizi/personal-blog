<?php
return array(
		"Name" => 'Name',
		"EMAIL" => 'Email',
		"TITLE" => 'Title',
		"CONTENT" => 'Content',
		"TIME" => 'Time',
		"AUDITED" => 'Audited',
		"NOT_AUDITED" => 'Not Audited',
		"AUDIT" => 'Audit',
		"CANCEL_AUDIT" => 'Cancel Audit'
);