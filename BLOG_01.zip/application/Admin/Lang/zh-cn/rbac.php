<?php
return array(
		"ROLE_NAME" => '角色名称',
		"ROLE_DESCRIPTION" => '角色描述',
		"ROLE_SETTING" => '权限设置',
);