<?php
namespace Blog\Controller;
use Common\Controller\AdminbaseController;

class IndexadminController extends AdminbaseController{
function index(){
  $this->display();
}
function aboutMe(){
        $this->display();
        }
}