<?php

namespace Blog\Controller;
use Common\Controller\HomebaseController;
class MessageBoardController extends HomebaseController{
   function index(){
               $this->display();
          }
}