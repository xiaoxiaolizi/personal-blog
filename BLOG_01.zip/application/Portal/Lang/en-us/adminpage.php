<?php
return array(
    "TITLE" => 'Title',
    "AUTHOR" => 'Author',
    "POST_DATE" => 'Date',
    "KEYWORD" => 'Keyword',
    "PLEASE_ENTER_KEYWORD" => 'Please enter the keyword...',
    "SEARCH" => 'Search'
);