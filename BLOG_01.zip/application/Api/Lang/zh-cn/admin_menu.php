<?php
return array (
  'API_GUESTBOOKADMIN_DELETE' => '删除网站留言',
  'API_GUESTBOOKADMIN_INDEX' => '所有留言',
  'API_OAUTHADMIN_SETTING_POST' => '提交设置',
  'API_OAUTHADMIN_SETTING' => '第三方登陆',
);