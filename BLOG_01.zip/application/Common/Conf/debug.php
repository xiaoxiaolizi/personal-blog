<?php
return array(
		'TMPL_DETECT_THEME'     => false,       // 自动侦测模板主题
		'SHOW_PAGE_TRACE'		=> true,
		'SHOW_RUN_TIME'			=> false,
		'TMPL_STRIP_SPACE'      => false,
		'HTML_CACHE_ON'         => false, // 开启静态缓存
);